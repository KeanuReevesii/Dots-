﻿using Unity.Entities;

public struct GameConfigData : IComponentData
{
    public Entity bulletPortotype;
    public Entity enemyPortotype;
}