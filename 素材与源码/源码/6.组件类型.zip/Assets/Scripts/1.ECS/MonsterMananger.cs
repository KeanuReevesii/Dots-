﻿using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using UnityEngine;

public class MonsterManangerAuthoring : MonoBehaviour
{
    public GameObject bulletPrefab;

    public class MonsterManangerBaker : Baker<MonsterManangerAuthoring>
    {
        public override void Bake(MonsterManangerAuthoring authoring)
        {
            Entity entity = GetEntity(TransformUsageFlags.None);
            AddComponent<GameConfig>(entity, new GameConfig()
            {
                bulletPrototype = GetEntity(authoring.bulletPrefab, TransformUsageFlags.Dynamic),
            });
        }
    }
}
