﻿using Unity.Burst;
using Unity.Entities;
using UnityEngine;

public class TestBurst : MonoBehaviour
{
    public readonly static SharedStatic<float> staticNum = SharedStatic<float>.GetOrCreate<KeyClass>(); // GetOrCreate<T> T是key

    public class KeyClass { }

    public static Entity entity;
    public float num;
    private void Awake()
    {
        staticNum.Data = 0;
    }
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // Debug.Log(staticNum.Data);
    }
}