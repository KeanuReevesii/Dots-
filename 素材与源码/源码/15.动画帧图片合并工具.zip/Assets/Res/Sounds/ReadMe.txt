Shooting Sound

it is a sound effects that can be used in games.

Contains 13 files.

It is free. It is freely usable.

Do not resell.

--------Contents-----

cannon_01.wav
cannon_02.wav
card.wav
crossbow.wav
electronic_01.wav
electronic_02.wav
heal.wav
laser_01
laser_02
machine_gun.wav
magic_01.wav
magic_02.wav
magic_03.wav


If you have any problems with the product, please contact us by e-mail.

4crain@gmail.com