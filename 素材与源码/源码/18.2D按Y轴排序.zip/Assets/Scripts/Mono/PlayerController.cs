﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PlayerState
{
    Idle, Move
}

public class PlayerController : MonoBehaviour
{
    public Animator animator;
    public float moveSpeed;
    public Vector2 moveRangeX;
    public Vector2 moveRangeY;
    public Transform gunRoot;
    public int lv = 1;
    public int bulletQuantity { get => lv; }
    public float attackCD { get => Mathf.Clamp(1F / lv * 1.5F, 0.1F, 1F); }
    public int LV
    {
        get => lv;
        set
        {
            lv = value;
            // TODO:因为等级导致的初始化数据
        }
    }

    public float spawnMonsterIntervaLMultiply = 1;
    public float spawnMonsterQnantityLMultiply = 1;
    private PlayerState playerState;
    public PlayerState PlayerState
    {
        get { return playerState; }
        set
        {
            playerState = value;
            switch (playerState)
            {
                case PlayerState.Idle:
                    PlayAnimation("Idle");
                    break;
                case PlayerState.Move:
                    PlayAnimation("Move");
                    break;
            }
        }
    }

    private void Awake()
    {
        LV = lv; // 为了初始化
    }

    private void Start()
    {
        PlayerState = PlayerState.Idle;
    }
    private void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        switch (playerState)
        {
            case PlayerState.Idle:
                if (h != 0 || v != 0) PlayerState = PlayerState.Move;
                break;
            case PlayerState.Move:
                if (h == 0 && v == 0)
                {
                    PlayerState = PlayerState.Idle;
                    return;
                }
                transform.Translate(moveSpeed * Time.deltaTime * new Vector3(h, v, 0));
                CheckPositionRange();
                if (h > 0) transform.localScale = Vector3.one;
                else if (h < 0) transform.localScale = new Vector3(-1, 1, 1);
                break;
        }
    }

    private void CheckPositionRange()
    {
        Vector3 pos = transform.position;
        pos.x = Mathf.Clamp(pos.x, moveRangeX.x, moveRangeX.y);
        pos.y = Mathf.Clamp(pos.y, moveRangeY.x, moveRangeY.y);
        pos.z = pos.y;
        transform.position = pos;
    }


    public void PlayAnimation(string animationName)
    {
        animator.CrossFadeInFixedTime(animationName, 0);
    }

}
