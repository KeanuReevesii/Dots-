﻿using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Jobs;
using UnityEngine;
using UnityEngine.UIElements;

public class TestJobSystem : MonoBehaviour
{
    // Run()：在主线程执行
    // Schedule()：在1个工作线程中完成全部任务
    // ScheduleParallel():在X个工作线程中完成各自的任务，并行

    private MyJob job;
    private NativeArray<int> nums; // Unity.Collections里的容器 都是相当于指针操作器，虽然是结构体但是传值后如果发生变化 特殊性在于不具备像结构体那样拷贝赋值的特性
    void Start()
    {
        Debug.Log("主线程:" + System.Threading.Thread.CurrentThread.ManagedThreadId);
        nums = new NativeArray<int>(100, Allocator.Persistent);
        job = new MyJob() { nums = nums };
        job.ScheduleParallel(100, 10, default(JobHandle)); // 一个组完成10件任，每个组在不同工作线程
        Invoke("Test", 3);
    }

    void Test()
    {
        for (int i = 0; i < nums.Length; i++)
        {
            Debug.Log(nums[i]);
        }
        nums.Dispose(); // job如果在运作，销毁会报错
    }
}

public struct MyJob : IJobFor
{
    public NativeArray<int> nums;
    public void Execute(int index)
    {
        nums[index] = index;
        //Debug.Log("JOB线程:" + System.Threading.Thread.CurrentThread.ManagedThreadId + "-Index:" + index);
    }
}
