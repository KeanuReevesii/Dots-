﻿using Unity.Entities;
using UnityEngine;

public class MonsterAuthoring : MonoBehaviour
{
    public float hp = 100;
    public float moveSpeed = 1;

    public class MonsterBaker : Baker<MonsterAuthoring>
    {
        public override void Bake(MonsterAuthoring authoring)
        {
            Entity monsterEntity = GetEntity(TransformUsageFlags.Dynamic);
            AddComponent<MonsterData>(monsterEntity, new MonsterData()
            {
                hp = authoring.hp,
                moveSpeed = authoring.moveSpeed,
            });
        }
    }
}
