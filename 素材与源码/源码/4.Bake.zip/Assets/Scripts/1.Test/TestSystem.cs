﻿using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;

public readonly partial struct MonsterAspect : IAspect
{
    public readonly RefRW<MonsterData> monsterData;
    public readonly RefRW<LocalTransform> localTransfrom;
}

public struct MonsterData : IComponentData
{
    public float hp;
    public float moveSpeed;
}

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct MonsterSystem : ISystem
{
    public void OnCreate(ref SystemState state)
    {

    }
    public void OnUpdate(ref SystemState state)
    {
        // SystemAPI:只能在System中使用，否则会报错
        // 筛选、遍历
        float3 dir = new float3(0, 0, 1);
        foreach (MonsterAspect monster in SystemAPI.Query<MonsterAspect>())
        {
            monster.localTransfrom.ValueRW.Position += SystemAPI.Time.DeltaTime * monster.monsterData.ValueRW.moveSpeed * dir;
            monster.monsterData.ValueRW.hp -= SystemAPI.Time.DeltaTime;
        }
    }
}
