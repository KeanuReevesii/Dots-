﻿using Unity.Entities;

public struct EnemyData : IComponentData, IEnableableComponent
{
    public bool die;
}
