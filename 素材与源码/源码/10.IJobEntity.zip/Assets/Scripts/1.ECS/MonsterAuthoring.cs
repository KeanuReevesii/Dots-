﻿using System.Collections.Generic;
using System.Threading;
using Unity.Entities;
using UnityEngine;

public class MonsterAuthoring : MonoBehaviour
{
    public float hp = 100;
    public float moveSpeed = 1;
    public float createBulletInterval = 1;

    public List<int> skills = new List<int>();

    public class MonsterBaker : Baker<MonsterAuthoring>
    {
        public override void Bake(MonsterAuthoring authoring)
        {
            Entity monsterEntity = GetEntity(TransformUsageFlags.Dynamic);
            AddComponent<MonsterData>(monsterEntity, new MonsterData()
            {

                hp = authoring.hp,
            });

            SetComponentEnabled<MonsterData>(monsterEntity, true);

            AddSharedComponent<MonsterConfig>(monsterEntity, new MonsterConfig()
            {
                createBulletInterval = authoring.createBulletInterval
            });
            AddComponent<MoveData>(monsterEntity, new MoveData()
            {
                moveSpeed = authoring.moveSpeed,
            });

            AddBuffer<Skill>(monsterEntity);
            for (int i = 0; i < authoring.skills.Count; i++)
            {
                AppendToBuffer<Skill>(monsterEntity, new Skill() { id = authoring.skills[i] });
            }
        }
    }
}
