﻿using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using Unity.Collections;
public struct Skill : IBufferElementData
{
    public int id;
}

public readonly partial struct MonsterAspect : IAspect
{
    public readonly RefRW<LocalTransform> localTransfrom;
    public readonly RefRW<MonsterData> monsterData;
    public readonly MonsterConfig monsterConfig;
    public readonly DynamicBuffer<Skill> skills;

}

public readonly partial struct MoverAspect : IAspect
{
    public readonly RefRW<MoveData> moveData;
    public readonly RefRW<LocalTransform> localTransfrom;
    // public readonly RefRO<MoveTag> tag;

}

public struct MonsterData : IComponentData, IEnableableComponent
{
    public float hp;
    public float createBulletTimer;
}

public struct MonsterConfig : ISharedComponentData
{
    public float createBulletInterval;
}

public struct GameConfig : IComponentData
{
    public Entity bulletPrototype;
}


public struct MoveData : IComponentData
{
    public float moveSpeed;
}

public struct MoveTag : IComponentData
{ }

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct MonsterSystem : ISystem
{
    public void OnCreate(ref SystemState state)
    {
        state.RequireForUpdate<GameConfig>(); // 如果没有这个组件则不会执行Update
    }
    public void OnUpdate(ref SystemState state)
    {
        GameConfig gameConfig = SystemAPI.GetSingleton<GameConfig>();
        //foreach (MonsterAspect monster in SystemAPI.Query<MonsterAspect>())
        //{
        //    monster.monsterData.ValueRW.hp -= SystemAPI.Time.DeltaTime;
        //    monster.monsterData.ValueRW.createBulletTimer -= SystemAPI.Time.DeltaTime; ;
        //    if (monster.monsterData.ValueRO.createBulletTimer <= 0)
        //    {
        //        monster.monsterData.ValueRW.createBulletTimer = monster.monsterConfig.createBulletInterval;
        //        Entity bullet = state.EntityManager.Instantiate(gameConfig.bulletPrototype);
        //        state.EntityManager.SetComponentData(bullet, new LocalTransform()
        //        {
        //            Position = monster.localTransfrom.ValueRO.Position,
        //            Scale = 0.5f
        //        });
        //    }
        //}

        // state.Dependency.Complete(); // 确定之前的job都完成

        // EntityCommandBuffer ecb = new EntityCommandBuffer(Allocator.TempJob);

        // 我们只管获取，后续不管
        EntityCommandBuffer ecb = SystemAPI.GetSingleton<EndSimulationEntityCommandBufferSystem.Singleton>().CreateCommandBuffer(state.WorldUnmanaged);
        new MonsterJob()
        {
            gameConfig = gameConfig,
            deltaTime = SystemAPI.Time.DeltaTime,
            ecb = ecb
        }.Schedule(); // 隐式依赖，如果填写state.Dependency则意味着显式管理
        // state.Dependency.Complete();
        //ecb.Playback(state.EntityManager);
        //ecb.Dispose();
    }
    public partial struct MonsterJob : IJobEntity
    {
        public float deltaTime;
        public GameConfig gameConfig;
        public EntityCommandBuffer ecb;
        public void Execute(MonsterAspect monster)
        {
            monster.monsterData.ValueRW.hp -= deltaTime;
            monster.monsterData.ValueRW.createBulletTimer -= deltaTime;
            if (monster.monsterData.ValueRO.createBulletTimer <= 0)
            {
                monster.monsterData.ValueRW.createBulletTimer = monster.monsterConfig.createBulletInterval;
                Entity bullet = ecb.Instantiate(gameConfig.bulletPrototype);
                ecb.SetComponent(bullet, new LocalTransform()
                {
                    Position = monster.localTransfrom.ValueRO.Position,
                    Scale = 0.5f
                });
                //Entity bullet = entityManager.Instantiate(gameConfig.bulletPrototype);
                //entityManager.SetComponentData(bullet, new LocalTransform()
                //{
                //    Position = monster.localTransfrom.ValueRO.Position,
                //    Scale = 0.5f
                //});
            }
        }
    }
}
[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct MoveSystem : ISystem
{
    public void OnUpdate(ref SystemState state)
    {
        // SystemAPI:只能在System中使用，否则会报错
        // 筛选、遍历
        float3 dir = new float3(0, 0, 1);
        //foreach (MoverAspect mover in SystemAPI.Query<MoverAspect>())
        //{
        //    mover.localTransfrom.ValueRW.Position += SystemAPI.Time.DeltaTime * mover.moveData.ValueRW.moveSpeed * dir;
        //}

        new MoveJob()
        {
            deltaTime = SystemAPI.Time.DeltaTime,
            dir = dir
        }.ScheduleParallel();
    }

    public partial struct MoveJob : IJobEntity
    {
        public float deltaTime;
        public float3 dir;
        public void Execute(MoverAspect mover, in Entity entity, in MoveTag tag)
        {
            mover.localTransfrom.ValueRW.Position += deltaTime * mover.moveData.ValueRW.moveSpeed * dir;
            // UnityEngine.Debug.Log("JOB线程:" + System.Threading.Thread.CurrentThread.ManagedThreadId + "E:" + entity);
        }

        //public void Execute(ref MoveData moveData, ref LocalTransform localTransfrom, in MoveTag tag)
        //{
        //    localTransfrom.Position += deltaTime * moveData.moveSpeed * dir;
        //    UnityEngine.Debug.Log("JOB线程:" + System.Threading.Thread.CurrentThread.ManagedThreadId);
        //}
    }
}
