﻿using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;

public readonly partial struct MonsterAspect : IAspect
{
    public readonly RefRW<LocalTransform> localTransfrom;
    public readonly RefRW<MonsterData> monsterData;
}

public readonly partial struct MoverAspect : IAspect
{
    public readonly RefRW<MoveData> moveData;
    public readonly RefRW<LocalTransform> localTransfrom;
}

public struct MonsterData : IComponentData
{
    public float hp;
    public Entity bulletPrototype;
    public float createBulletTimer;
    public float createBulletInterval;
}

public struct MoveData : IComponentData
{
    public float moveSpeed;
}

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct MonsterSystem : ISystem
{
    public void OnUpdate(ref SystemState state)
    {
        foreach (MonsterAspect monster in SystemAPI.Query<MonsterAspect>())
        {
            monster.monsterData.ValueRW.hp -= SystemAPI.Time.DeltaTime;
            monster.monsterData.ValueRW.createBulletTimer -= SystemAPI.Time.DeltaTime; ;
            if (monster.monsterData.ValueRO.createBulletTimer <= 0)
            {
                monster.monsterData.ValueRW.createBulletTimer = monster.monsterData.ValueRO.createBulletInterval;
                Entity bullet = state.EntityManager.Instantiate(monster.monsterData.ValueRO.bulletPrototype);
                state.EntityManager.SetComponentData(bullet, new LocalTransform()
                {
                    Position = monster.localTransfrom.ValueRO.Position,
                    Scale = 0.5f
                });
            }
        }
    }
}

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct MoveSystem : ISystem
{
    public void OnUpdate(ref SystemState state)
    {
        // SystemAPI:只能在System中使用，否则会报错
        // 筛选、遍历
        float3 dir = new float3(0, 0, 1);
        foreach (MoverAspect mover in SystemAPI.Query<MoverAspect>())
        {
            mover.localTransfrom.ValueRW.Position += SystemAPI.Time.DeltaTime * mover.moveData.ValueRW.moveSpeed * dir;
        }
    }
}
