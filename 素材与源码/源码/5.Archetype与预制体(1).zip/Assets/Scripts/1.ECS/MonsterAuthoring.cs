﻿using Unity.Entities;
using UnityEngine;

public class MonsterAuthoring : MonoBehaviour
{
    public float hp = 100;
    public float moveSpeed = 1;
    public float createBulletInterval = 1;
    public GameObject bulletPrefab;

    public class MonsterBaker : Baker<MonsterAuthoring>
    {
        public override void Bake(MonsterAuthoring authoring)
        {
            Entity monsterEntity = GetEntity(TransformUsageFlags.Dynamic);
            AddComponent<MonsterData>(monsterEntity, new MonsterData()
            {
                hp = authoring.hp,
                bulletPrototype = GetEntity(authoring.bulletPrefab, TransformUsageFlags.Dynamic),
                createBulletInterval = authoring.createBulletInterval
            });
            AddComponent<MoveData>(monsterEntity, new MoveData()
            {
                moveSpeed = authoring.moveSpeed,
            });
        }
    }
}
