﻿using Unity.Entities;

public struct BulletData : IComponentData
{
    public float destroyTimer;
}