﻿using Unity.Entities;

public partial struct BulletSystem : ISystem
{
    public void OnCreate(ref SystemState state)
    {
        SharedData.singtonEnitty.Data = state.EntityManager.CreateEntity(typeof(BulletInfo));
    }

}