﻿using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Transforms;

public partial struct BulletSystem : ISystem
{
    public void OnCreate(ref SystemState state)
    {
        SharedData.singtonEnitty.Data = state.EntityManager.CreateEntity(typeof(BulletCreateInfo));
    }
    public void OnUpdate(ref SystemState state)
    {
        EntityCommandBuffer.ParallelWriter ecb = SystemAPI.GetSingleton<EndSimulationEntityCommandBufferSystem.Singleton>().CreateCommandBuffer(state.WorldUnmanaged).AsParallelWriter();
        new BulletJob()
        {
            ecb = ecb,
            deltaTime = SystemAPI.Time.DeltaTime,
        }.ScheduleParallel();

        DynamicBuffer<BulletCreateInfo> bulletCreateInfoBuffer = SystemAPI.GetSingletonBuffer<BulletCreateInfo>();
        if (bulletCreateInfoBuffer.Length == 0) return;
        NativeArray<Entity> newBullets = new NativeArray<Entity>(bulletCreateInfoBuffer.Length, Allocator.Temp);
        state.EntityManager.Instantiate(SystemAPI.GetSingleton<GameConfigData>().bulletPortotype, newBullets);
        for (int i = 0; i < bulletCreateInfoBuffer.Length; i++)
        {
            BulletCreateInfo info = bulletCreateInfoBuffer[i];
            ecb.SetComponent<LocalTransform>(newBullets[i].Index, newBullets[i], new LocalTransform()
            {
                Position = info.position,
                Rotation = info.rotation,
                Scale = 1
            });
        }
        bulletCreateInfoBuffer.Clear();
        newBullets.Dispose();
    }


    [BurstCompile]
    public partial struct BulletJob : IJobEntity
    {
        public EntityCommandBuffer.ParallelWriter ecb;
        public float deltaTime;
        public void Execute(ref BulletData bulletData, in BulletSharedData bulletSharedData, in Entity entity, ref LocalTransform localTransform)
        {
            // 位置移动
            localTransform.Position += bulletSharedData.moveSpeed * deltaTime * localTransform.Up();
            // 销毁计时
            bulletData.destroyTimer -= deltaTime;
            if (bulletData.destroyTimer <= 0)
            {
                ecb.DestroyEntity(entity.Index, entity);
            }
        }
    }
}