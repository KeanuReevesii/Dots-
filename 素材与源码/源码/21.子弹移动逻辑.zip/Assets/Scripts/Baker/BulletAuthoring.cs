﻿using Unity.Entities;
using UnityEngine;

public class BulletAuthoring : MonoBehaviour
{
    public float moveSpeed;
    public float destroyTime;

    public class BulletBaker : Baker<BulletAuthoring>
    {
        public override void Bake(BulletAuthoring authoring)
        {
            Entity entity = GetEntity(TransformUsageFlags.Dynamic);
            AddComponent<RendererSortTag>(entity);
            AddComponent<BulletData>(entity, new BulletData()
            {
                destroyTimer = authoring.destroyTime
            });
            SetComponentEnabled<RendererSortTag>(entity, true);
            AddSharedComponent<BulletSharedData>(entity, new BulletSharedData()
            {
                moveSpeed = authoring.moveSpeed,
                destroyTime = authoring.destroyTime
            });
        }
    }
}