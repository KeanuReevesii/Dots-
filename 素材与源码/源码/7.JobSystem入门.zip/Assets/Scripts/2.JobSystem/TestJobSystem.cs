﻿using System.Collections;
using System.Collections.Generic;
using Unity.Jobs;
using UnityEngine;

public class TestJobSystem : MonoBehaviour
{
    // Run()：在主线程执行
    // Schedule()：在工作线程执行
    void Start()
    {
        Debug.Log("主线程:" + System.Threading.Thread.CurrentThread.ManagedThreadId);
        for (int i = 0; i < 10; i++)
        {
            MyJob job = new MyJob();
            job.Schedule();
        }
    }
}

public struct MyJob : IJob
{
    // Job实际会执行的函数
    public void Execute()
    {
        Debug.Log("JOB");
        Debug.Log("JOB线程:" + System.Threading.Thread.CurrentThread.ManagedThreadId);
    }
}