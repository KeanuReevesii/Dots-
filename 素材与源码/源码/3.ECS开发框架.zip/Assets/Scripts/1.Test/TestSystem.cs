﻿using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;

public readonly partial struct MonsterAspect : IAspect
{
    public readonly RefRW<MonsterData> monsterData;
    public readonly RefRW<LocalTransform> localTransfrom;
}

public struct MonsterData : IComponentData
{
    public float hp;
}

[UpdateInGroup(typeof(SimulationSystemGroup))]
public partial struct MonsterSystem : ISystem
{
    public void OnCreate(ref SystemState state)
    {
        Entity monster = state.EntityManager.CreateEntity(typeof(MonsterData), typeof(LocalTransform));
        state.EntityManager.SetComponentData(monster, new MonsterData()
        {
            hp = 100,
        });
    }
    public void OnUpdate(ref SystemState state)
    {
        // SystemAPI:只能在System中使用，否则会报错
        // 筛选、遍历
        float3 dir = new float3(0, 0, 1);
        foreach (MonsterAspect monster in SystemAPI.Query<MonsterAspect>())
        {
            monster.localTransfrom.ValueRW.Position += dir * SystemAPI.Time.DeltaTime;
            monster.monsterData.ValueRW.hp -= SystemAPI.Time.DeltaTime;
        }
    }
}
